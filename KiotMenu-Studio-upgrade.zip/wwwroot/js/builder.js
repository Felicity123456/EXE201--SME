'use strict';
const $ = id => document.getElementById(id), token = localStorage.getItem('jwtToken');
let doc, design, history = [], position = -1, dirty = false, busy = false;
const keys = ['accent','headline','description','announcement','showSearch','showDescriptions'];
async function api(path, options = {}) {
    const r = await fetch(path,{...options,headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`}});
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(r.status === 401 ? 'Phiên đăng nhập hết hạn. Vui lòng đăng nhập lại.' : d.message || 'Không thể kết nối. Vui lòng thử lại.');
    return d;
}
function notice(message, error = false) { $('notice').textContent = message; $('notice').classList.toggle('error',error); }
function preview() { if(design) $('preview').contentWindow?.postMessage({type:'menu-design',design},location.origin); }
function fill() {
    keys.forEach(k => {if ($(k).type === 'checkbox') $(k).checked = design[k]; else $(k).value = design[k] || '';});
    document.querySelectorAll('[data-template]').forEach(b => b.setAttribute('aria-pressed',String(b.dataset.template === design.template)));
    $('undo').disabled = position <= 0; $('redo').disabled = position >= history.length - 1;
    $('restore').disabled = !doc.published; preview();
}
function changed() {dirty = true; $('state').textContent = 'Có thay đổi chưa lưu';fill();}
function remember() {history = history.slice(0,position + 1);history.push(structuredClone(design));if(history.length > 60) history.shift();position = history.length - 1;changed();}
$('editor').addEventListener('submit', e => e.preventDefault());
$('editor').addEventListener('input', e => {if(keys.includes(e.target.id)) {design[e.target.id] = e.target.type === 'checkbox' ? e.target.checked : e.target.value;remember();}});
document.querySelectorAll('[data-template]').forEach(b => b.onclick = () => {design.template = b.dataset.template;design.accent = {coffee:'#d97706',garden:'#15803d',modern:'#4f46e5'}[design.template];remember();});
$('undo').onclick = () => {if(position > 0) {design = structuredClone(history[--position]);changed();}};
$('redo').onclick = () => {if(position < history.length - 1) {design = structuredClone(history[++position]);changed();}};
$('restore').onclick = () => {if(doc.published) {design = structuredClone(doc.published);remember();notice('Đã khôi phục bản xuất bản vào trình chỉnh sửa.');}};
function publishedDate() {$('date').textContent = doc.publishedAt ? `Xuất bản: ${new Date(doc.publishedAt).toLocaleString('vi-VN')}` : 'Chưa xuất bản thiết kế';}
async function save(publish) {
    if(busy || !$('editor').reportValidity()) return;
    busy = true; $('save').disabled = $('publish').disabled = true; $('fields').disabled = true;
    try {doc = await api('/api/store/design',{method:'PUT',body:JSON.stringify({design,revision:doc.revision,publish})});dirty = false;$('state').textContent = 'Đã lưu trên hệ thống';publishedDate();notice(publish ? 'Đã xuất bản! Menu khách đã sử dụng thiết kế mới.' : 'Đã lưu nháp. Bạn có thể tiếp tục chỉnh sửa.');fill();}
    catch(e) {notice(e.message,true);} finally {busy = false;$('fields').disabled = false;$('save').disabled = $('publish').disabled = false;}
}
$('save').onclick = () => save(false);$('publish').onclick = () => save(true);
['mobile','desktop'].forEach(mode => $(mode).onclick = () => {$('preview').classList.toggle('desktop',mode === 'desktop');['mobile','desktop'].forEach(m => $(m).setAttribute('aria-pressed',String(m === mode)));});
$('preview').onload = preview;
window.addEventListener('message',e => {if(e.origin === location.origin && e.source === $('preview').contentWindow && e.data?.type === 'menu-ready') preview();});
window.addEventListener('beforeunload',e => {if(dirty) {e.preventDefault();e.returnValue = '';}});
(async () => {
    if(!token) {notice('Vui lòng đăng nhập từ trang chủ trước khi thiết kế menu.',true);$('state').textContent = 'Chưa đăng nhập';return;}
    try {const [store,document,menu] = await Promise.all([api('/api/store/info'),api('/api/store/design'),api('/api/store/menu')]);doc = document;design = structuredClone(doc.draft);history = [structuredClone(design)];position = 0;$('storeName').textContent = store.storeName;const url = `/menu.html?slug=${encodeURIComponent(store.slug)}`;$('publicLink').href = url;$('publicLink').hidden = false;$('preview').src = url + '&preview=1';$('empty').hidden = menu.some(c => c.menuItems.some(m => m.isAvailable));publishedDate();$('state').textContent = 'Đã tải bản nháp';$('fields').disabled = false;$('save').disabled = $('publish').disabled = false;fill();}
    catch(e) {notice(e.message,true);$('state').textContent = 'Chưa tải được thiết kế';}
})();
