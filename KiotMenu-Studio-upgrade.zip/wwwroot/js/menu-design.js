(() => {
    const el = id => document.getElementById(id);
    const defaults = {accent:'#d97706',template:'coffee',headline:'Một chút ngon, một ngày vui',description:'Chọn món yêu thích và gọi ngay tại bàn.',showSearch:true,showDescriptions:true};
    window.applyMenuDesign = design => {
        const d = {...defaults,...design};
        document.documentElement.style.setProperty('--accent', /^#[\da-f]{6}$/i.test(d.accent) ? d.accent : defaults.accent);
        document.body.dataset.template = ['coffee','garden','modern'].includes(d.template) ? d.template : 'coffee';
        el('designHeadline').textContent = d.headline;
        el('designDescription').textContent = d.description || '';
        el('designAnnouncement').textContent = d.announcement || '';
        el('designAnnouncement').hidden = !d.announcement;
        el('menuSearch').hidden = !d.showSearch;
        document.body.classList.toggle('hide-descriptions', !d.showDescriptions);
    };
    el('menuSearch').addEventListener('input', e => {
        const normalize = s => s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').toLowerCase();
        const query = normalize(e.target.value.trim());
        let matches = 0;
        document.querySelectorAll('.mon').forEach(m => {m.hidden = !normalize(m.textContent).includes(query); if (!m.hidden) matches++;});
        el('searchEmpty').hidden = matches > 0;
    });
    if (new URLSearchParams(location.search).get('preview') === '1') {
        document.body.classList.add('design-preview');
        window.addEventListener('message', e => {
            if (e.origin === location.origin && e.source === parent && e.data?.type === 'menu-design') window.applyMenuDesign(e.data.design);
        });
    }
    window.applyMenuDesign(defaults);
})();
