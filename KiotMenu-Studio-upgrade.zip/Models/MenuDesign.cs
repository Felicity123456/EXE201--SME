using System.ComponentModel.DataAnnotations;
using System.Text.Json;

namespace MyMenuApi.Models;

public sealed record MenuDesign
{
    [Required, RegularExpression("^#[0-9a-fA-F]{6}$")]
    public string Accent { get; init; } = "#d97706";
    [Required, RegularExpression("^(coffee|garden|modern)$")]
    public string Template { get; init; } = "coffee";
    [Required, StringLength(100)]
    public string Headline { get; init; } = "Một chút ngon, một ngày vui";
    [StringLength(300)]
    public string? Description { get; init; } = "Chọn món yêu thích và gọi ngay tại bàn.";
    [StringLength(180)]
    public string? Announcement { get; init; }
    public bool ShowSearch { get; init; } = true;
    public bool ShowDescriptions { get; init; } = true;
}

// Stored in the existing ThemeConfigJson column; no database migration required.
public sealed record MenuDesignDocument
{
    public MenuDesign Draft { get; init; } = new();
    public MenuDesign? Published { get; init; }
    public DateTime? PublishedAt { get; init; }
    public int Revision { get; init; }
    public static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public static MenuDesignDocument Read(string? json)
    {
        try { return string.IsNullOrEmpty(json) ? new() : JsonSerializer.Deserialize<MenuDesignDocument>(json, JsonOptions) ?? new(); }
        catch (JsonException) { return new(); }
    }
}
