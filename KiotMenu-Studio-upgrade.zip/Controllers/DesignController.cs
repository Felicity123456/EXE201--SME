using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyMenuApi.Data;
using MyMenuApi.Models;
using System.Text.Json;

namespace MyMenuApi.Controllers;

[Authorize, ApiController, Route("api/store/design")]
public class DesignController(AppDbContext db) : ControllerBase
{
    private async Task<Store?> MyStore() => Guid.TryParse(User.FindFirst("StoreId")?.Value, out var id)
        ? await db.Stores.FindAsync(id) : null;

    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var store = await MyStore();
        return store is null ? NotFound(new { message = "Không tìm thấy quán của bạn." })
            : Ok(MenuDesignDocument.Read(store.ThemeConfigJson));
    }

    public record SaveDesignRequest([Required] MenuDesign Design, int Revision, bool Publish);

    [HttpPut]
    public async Task<IActionResult> Save(SaveDesignRequest request)
    {
        var store = await MyStore();
        if (store is null) return NotFound(new { message = "Không tìm thấy quán của bạn." });
        // Serialize edits per store in the database, including across application instances.
        await using var transaction = await db.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable);
        await db.Entry(store).ReloadAsync();
        var current = MenuDesignDocument.Read(store.ThemeConfigJson);
        if (current.Revision != request.Revision)
            return Conflict(new { message = "Thiết kế đã được sửa ở cửa sổ khác. Hãy tải lại trước khi lưu." });
        var next = current with
        {
            Draft = request.Design,
            Published = request.Publish ? request.Design : current.Published,
            PublishedAt = request.Publish ? DateTime.UtcNow : current.PublishedAt,
            Revision = current.Revision + 1
        };
        store.ThemeConfigJson = JsonSerializer.Serialize(next, MenuDesignDocument.JsonOptions);
        await db.SaveChangesAsync();
        await transaction.CommitAsync();
        return Ok(next);
    }
}

