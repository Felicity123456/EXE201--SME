using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using MyMenuApi.Data;
using MyMenuApi.Hubs;
using MyMenuApi.Models;

namespace MyMenuApi.Controllers;

[ApiController]
[Route("api/public")]
public class PublicMenuController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IHubContext<OrderHub> _hubContext;

    public PublicMenuController(AppDbContext db, IHubContext<OrderHub> hubContext)
    {
        _db = db;
        _hubContext = hubContext;
    }

    // 0. Danh sách mẫu menu cho trang chủ chọn.
    //
    // Trước đây các mẫu viết cứng trong index.html, muốn thêm mẫu phải sửa HTML.
    // Giờ lấy từ bảng MenuTemplates, thêm mẫu chỉ cần thêm một dòng trong CSDL.
    [HttpGet("templates")]
    public async Task<IActionResult> GetTemplates()
    {
        var templates = await _db.MenuTemplates
            .OrderBy(t => t.Name)
            .Select(t => new { t.Id, t.Name, t.Description, t.ThumbnailUrl, t.Category, t.Price })
            .ToListAsync();

        return Ok(templates);
    }

    // 1. Lấy toàn bộ Menu công khai cho khách xem qua Slug
    //
    // Tham số `table` là MÃ BÀN trên link QR (ví dụ B01), không phải Id.
    //
    // Trước đây trang khách không đặt món được: link QR chỉ mang slug và mã bàn,
    // trong khi POST /api/public/orders đòi storeId và tableId dạng GUID, mà không
    // có endpoint nào đổi cái này sang cái kia. Giờ trả luôn storeId, và trả thêm
    // tableId khi có mã bàn.
    [HttpGet("menu/{slug}")]
    public async Task<IActionResult> GetPublicMenu(string slug, [FromQuery] string? table)
    {
        var store = await _db.Stores
            .Include(s => s.Categories)
            .ThenInclude(c => c.MenuItems)
            .FirstOrDefaultAsync(s => s.Slug == slug);

        if (store == null) return NotFound(new { message = "Quán không tồn tại." });

        // Mẫu menu quán đã chọn. Trang hiển thị cho khách dùng cái này để biết vẽ
        // theo giao diện nào — trước đây Store.TemplateId không bao giờ được gán
        // nên chỗ này luôn rỗng.
        var mau = store.TemplateId is Guid tid
            ? await _db.MenuTemplates
                .Where(t => t.Id == tid)
                .Select(t => new { t.Id, t.Name, t.Category })
                .FirstOrDefaultAsync()
            : null;

        // Chỉ tra đúng cái bàn trên link QR, không trả cả danh sách bàn — người lạ
        // không cần biết quán có bao nhiêu bàn.
        object? banQr = null;
        if (!string.IsNullOrWhiteSpace(table))
        {
            banQr = await _db.Tables
                .Where(t => t.StoreId == store.Id && t.TableCode == table)
                .Select(t => new { t.Id, t.TableName, t.TableCode })
                .FirstOrDefaultAsync();
        }

        return Ok(new
        {
            StoreId = store.Id,
            store.StoreName,
            store.LogoUrl,
            Design = MenuDesignDocument.Read(store.ThemeConfigJson).Published,
            Table = banQr,
            Template = mau,
            Categories = store.Categories.Select(c => new
            {
                c.Id,
                c.CategoryName,
                MenuItems = c.MenuItems.Where(m => m.IsAvailable)
            })
        });
    }

    // DTOs cho Đặt món
    public record OrderItemDto(Guid MenuItemId, int Quantity, string? Note);
    public record CreateOrderDto(Guid StoreId, Guid TableId, string? Note, List<OrderItemDto> Items);

    // 2. Khách gửi đơn Đặt món (Order)
    [HttpPost("orders")]
    public async Task<IActionResult> CreateOrder([FromBody] CreateOrderDto dto)
    {
        if (dto.Items == null || !dto.Items.Any())
            return BadRequest(new { message = "Vui lòng chọn ít nhất 1 món." });

        decimal total = 0;
        var orderItems = new List<OrderItem>();

        foreach (var item in dto.Items)
        {
            var menuItem = await _db.MenuItems.FindAsync(item.MenuItemId);

            // Bản cũ: món không tìm thấy thì BỎ QUA im lặng, đơn vẫn tạo. Khách gọi
            // 3 món có thể chỉ ra 2 mà không ai biết. Giờ từ chối cả đơn.
            if (menuItem is null)
                return BadRequest(new { message = "Trong đơn có món không còn tồn tại. Hãy tải lại thực đơn." });

            if (!menuItem.IsAvailable)
                return BadRequest(new { message = $"Món \"{menuItem.Name}\" vừa hết. Hãy bỏ khỏi giỏ rồi gửi lại." });

            if (item.Quantity <= 0)
                return BadRequest(new { message = "Số lượng phải lớn hơn 0." });

            total += menuItem.Price * item.Quantity;
            orderItems.Add(new OrderItem
            {
                MenuItemId = item.MenuItemId,
                Quantity = item.Quantity,
                UnitPrice = menuItem.Price,
                Note = item.Note
            });
        }

        var order = new Order
        {
            StoreId = dto.StoreId,
            TableId = dto.TableId,
            TotalPrice = total,
            Status = "Pending",
            Note = dto.Note,
            OrderItems = orderItems
        };

        _db.Orders.Add(order);
        await _db.SaveChangesAsync();

        // GỬI THÔNG BÁO REAL-TIME QUA SIGNALR
        var table = await _db.Tables.FirstOrDefaultAsync(t => t.Id == dto.TableId);
        var tableName = table != null ? table.TableName : "Bàn không xác định";

        var orderNotification = new
        {
            OrderId = order.Id,
            TableName = tableName,
            TotalPrice = order.TotalPrice,
            Status = order.Status,
            Note = order.Note,
            CreatedAt = order.CreatedAt
        };

        await _hubContext.Clients.Group(dto.StoreId.ToString())
            .SendAsync("ReceiveNewOrder", orderNotification);

        return Ok(new { message = "Đặt món thành công!", orderId = order.Id, totalPrice = total });
    }
}
